Configuration web-deploy {

    Param (
    [string]$drive = 'G'
)

Import-DscResource -Module PSDesiredStateConfiguration

Node localhost {

Script serverManager {
    SetScript  = {
        Get-ScheduledTask ServerManager | Disable-ScheduledTask
        Write-Verbose "Disabled Server Manager on login"
    }
    TestScript = { ( Get-ScheduledTask ServerManager ).state -eq 'disabled' }
    GetScript  = { return @{ 'Result' = "Turn Off Server Manager at logon" }
    }
}

WindowsFeature IIS
{
    Ensure = 'Present'
    Name = 'Web-Server'
}

WindowsFeatureSet Webserver
{
    Name = @("Web-App-Dev","Web-Asp-Net45", "Web-Common-Http", "Web-Default-Doc", "Web-Dir-Browsing", "Web-Dyn-Compression", "Web-Filtering", "Web-Http-Errors", "Web-Http-Logging", "Web-ISAPI-Ext", "Web-ISAPI-Filter", "Web-Mgmt-Console", "Web-Mgmt-Tools", "Web-Net-Ext45", "Web-Performance", "Web-Security", "Web-Stat-Compression", "Web-Static-Content", "Web-WebServer", "Web-Windows-Auth")
    Ensure = 'Present'
    DependsOn = '[WindowsFeature]IIS'
}

File WebsiteContent {
    Ensure = "Present"
    Type = "File"
    Contents   = "<h1>welcome to mycompany.com</h1>"
    DestinationPath = "c:\inetpub\wwwroot\index.htm"
}

Script chocostuff {
    SetScript            = {
        [Net.ServicePointManager]::SecurityProtocol = "tls12"
        if ( !( Test-Path 'C:\ProgramData\chocolatey\choco.exe' ) ) {
            Set-ExecutionPolicy Bypass -Scope Process -Force; Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
        }
        C:\ProgramData\chocolatey\choco.exe install googlechrome, 7zip, notepadplusplus --ignore-checksums -y
}
    TestScript           = { $false }
    GetScript            = { return @{ 'Result' = "installs chocolatey and packages" } }
}

Script InitializeDrive {
    SetScript  = {
        Get-Disk | Where-Object { $_.DiskNumber -eq 2 -and $_.PartitionStyle -eq 'raw' } |
            Initialize-Disk -PartitionStyle MBR -PassThru |
            New-Partition -DriveLetter $using:drive -UseMaximumSize |
            Format-Volume -FileSystem NTFS -NewFileSystemLabel "Data" -Confirm:$false

        #Start-Sleep 5
        #Get-PSDrive | Out-Null

        #$ar = New-Object System.Security.AccessControl.FileSystemAccessRule('BUILTIN\Users', 'Modify', 'containerinherit,objectinherit', 'none', 'Allow')
        #$acl = Get-Acl "$using:drive`:"
        #$acl.AddAccessRule($ar)
        #Set-Acl "$using:drive`:" $acl

       # Set-Volume -DriveLetter c -NewFileSystemLabel "System"
        #$MaxSize = (Get-PartitionSupportedSize -DriveLetter c).sizeMax
        #Resize-Partition -DriveLetter c -Size $MaxSize -ErrorAction SilentlyContinue 
        }
    TestScript = {
        if ( ( Get-Item G:\ -ErrorAction SilentlyContinue ).LinkType -and ( Get-Partition | Where-Object { $_.DriveLetter -eq 'G' } ) ) { $true } else { $false }
    }
    GetScript  = { return @{ 'Result' = "format new data drive and create folders" } }
}

}
}